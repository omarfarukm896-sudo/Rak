RELISH TEA ANDROID PROJECT / অ্যান্ড্রয়েড প্রজেক্ট

This is the Android Studio source project for the Relish Tea HTML business app. It is NOT a compiled APK yet.
এটি Relish Tea অ্যাপের Android Studio source project। এটি এখনো তৈরি করা APK ফাইল নয়।

BUILD APK / APK তৈরি করার নিয়ম:
1. Install Android Studio on a Windows computer: https://developer.android.com/studio
   Windows কম্পিউটারে Android Studio ইনস্টল করুন।
2. Extract this ZIP file.
   ZIP ফাইলটি Extract করুন।
3. Android Studio > Open > select the extracted RelishTeaAndroid folder.
   Android Studio থেকে Open করে RelishTeaAndroid ফোল্ডারটি নির্বাচন করুন।
4. Wait for Gradle Sync and install the Android SDK requested by Android Studio.
   Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন এবং চাইলে Android SDK ইনস্টল করুন।
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
   Build মেনু থেকে Build APK(s) নির্বাচন করুন।
6. Android Studio will show the generated APK location, normally app/build/outputs/apk/debug/app-debug.apk.
   APK তৈরি হলে Android Studio ফাইলের অবস্থান দেখাবে।

NOTES / নোট:
- Data is stored locally on the device/browser storage. Back up JSON regularly.
- এই অ্যাপে ডাটা ডিভাইসের লোকাল স্টোরেজে থাকে। নিয়মিত JSON ব্যাকআপ রাখুন।
- Test invoice printing, logo upload, and JSON restore on the target phone before using for real business.
- বাস্তব ব্যবসায় ব্যবহারের আগে ফোনে ইনভয়েস প্রিন্ট, লোগো আপলোড এবং JSON restore পরীক্ষা করুন।
